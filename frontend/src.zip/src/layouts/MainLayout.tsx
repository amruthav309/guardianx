import type { ReactNode } from "react";

type Props = {
  children: ReactNode;
};

function MainLayout({ children }: Props) {
  return (
    <div className="min-h-screen bg-[#09090B] text-white">
      {children}
    </div>
  );
}

export default MainLayout;